// src/TaskDashboard.jsx
import { useState } from 'react';

export default function TaskDashboard() {
  // --- 1. STATE & MOCK DATA ---
  const [tasks, setTasks] = useState([
    {
      id: 1,
      title: "AUTH INTEGRATION",
      priority: "MEDIUM",
      dueDate: "2024-04-05",
      progress: 45,
      assignee: "https://i.pravatar.cc/150?u=1",
    },
    {
      id: 2,
      title: "PAYROLL SYSTEM",
      priority: "HIGH",
      dueDate: "2024-04-12",
      progress: 80,
      assignee: "https://i.pravatar.cc/150?u=2",
    },
    {
      id: 3,
      title: "DASHBOARD UI",
      priority: "LOW",
      dueDate: "2024-04-20",
      progress: 10,
      assignee: "https://i.pravatar.cc/150?u=3",
    }
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newTask, setNewTask] = useState({
    title: '',
    priority: 'MEDIUM',
    dueDate: '',
    progress: 0
  });

  // ฟังก์ชันเพิ่มงาน
  const handleCreateTask = (e) => {
    e.preventDefault();
    const taskData = {
      id: Date.now(),
      ...newTask,
      assignee: "https://i.pravatar.cc/150?u=99", // รูปคนสร้าง (เราเอง)
      progress: 0
    };
    setTasks([...tasks, taskData]);
    setIsModalOpen(false);
    setNewTask({ title: '', priority: 'MEDIUM', dueDate: '', progress: 0 });
  };

  // ฟังก์ชันเลือกสีป้าย Priority
  const getPriorityStyle = (priority) => {
    switch (priority) {
      case 'HIGH': return 'bg-red-50 text-red-600 border-red-100';
      case 'MEDIUM': return 'bg-orange-50 text-orange-500 border-orange-100'; // ในรูป Medium ออกส้มๆ
      case 'LOW': return 'bg-green-50 text-green-600 border-green-100';
      default: return 'bg-gray-50 text-gray-600';
    }
  };

  return (
    <div className="flex h-screen w-full bg-[#F3F4F6] font-sans overflow-hidden">
      
      {/* ================= SIDEBAR (ซ้าย) ================= */}
      <aside className="w-64 bg-[#111827] text-gray-400 flex flex-col shrink-0 transition-all duration-300">
        {/* Logo */}
        <div className="h-20 flex items-center px-8 bg-[#111827]">
          <div className="flex items-center gap-3 text-white">
            <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center shadow-lg shadow-red-900/50">
               <i className="fa-solid fa-bolt text-sm"></i>
            </div>
            <span className="font-bold text-lg tracking-wide">The Pulse</span>
          </div>
        </div>

        {/* Menu */}
        <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
          <SidebarItem icon="fa-chart-pie" text="Dashboard" />
          <SidebarItem icon="fa-calendar-check" text="My Day" />
          
          {/* Active Menu */}
          <div className="flex items-center px-4 py-3 bg-red-600 text-white rounded-xl shadow-lg shadow-red-900/20 cursor-pointer">
            <i className="fa-solid fa-layer-group w-6 text-center mr-3"></i>
            <span className="font-medium text-sm">Tasks</span>
          </div>

          <SidebarItem icon="fa-folder-tree" text="Project Flow" />
          <SidebarItem icon="fa-wallet" text="Budget & ROI" />
          <SidebarItem icon="fa-users" text="Payroll System" />
        </nav>

        {/* User Profile (ล่างสุด) */}
        <div className="p-6 border-t border-gray-800">
          <div className="flex items-center gap-3">
             <div className="relative">
                <img src="https://i.pravatar.cc/150?u=99" className="w-10 h-10 rounded-full border-2 border-[#1f2937]" alt="Profile" />
                <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-[#111827]"></div>
             </div>
             <div>
               <p className="text-white text-sm font-semibold">John Doe</p>
               <p className="text-xs text-gray-500">Admin Workspace</p>
             </div>
          </div>
        </div>
      </aside>


      {/* ================= MAIN CONTENT (ขวา) ================= */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        
        {/* Header */}
        <header className="flex justify-between items-center px-8 py-5 bg-white border-b border-gray-100 shrink-0">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 tracking-tight">TASKS</h1>
            <div className="flex items-center gap-2 text-[11px] font-semibold text-gray-400 mt-1 uppercase tracking-wider">
               <span>CC Project</span>
               <i className="fa-solid fa-chevron-right text-[8px]"></i>
               <span className="text-red-500">Overview</span>
            </div>
          </div>
          
          <button 
            onClick={() => setIsModalOpen(true)}
            className="group flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-full font-medium shadow-lg hover:shadow-red-200 transition-all active:scale-95"
          >
            <div className="w-5 h-5 bg-white/20 rounded-full flex items-center justify-center group-hover:bg-white/30">
               <i className="fa-solid fa-plus text-[10px]"></i>
            </div>
            <span className="text-sm">Create Task</span>
          </button>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto p-8 bg-[#F3F4F6]">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            
            {/* --- Loop Render Cards --- */}
            {tasks.map((task) => (
              <div key={task.id} className="bg-white rounded-[20px] p-6 shadow-[0_2px_20px_-10px_rgba(0,0,0,0.05)] border border-gray-100 hover:border-red-100 hover:shadow-[0_8px_25px_-10px_rgba(220,38,38,0.1)] transition-all duration-300 group cursor-pointer relative">
                
                {/* Dots Menu */}
                <div className="absolute top-5 right-5 text-gray-300 group-hover:text-gray-500 transition">
                   <i className="fa-solid fa-ellipsis"></i>
                </div>

                {/* Tags */}
                <div className="mb-5 flex gap-2">
                   <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-bold tracking-wide uppercase">Design</span>
                   <span className={`px-3 py-1 rounded-lg text-[10px] font-bold tracking-wide border uppercase ${getPriorityStyle(task.priority)}`}>
                      {task.priority}
                   </span>
                </div>

                {/* Title */}
                <h3 className="text-base font-bold text-gray-800 mb-1 leading-tight">{task.title}</h3>
                <p className="text-gray-400 text-xs mb-6 font-medium">Due Date: {task.dueDate}</p>

                {/* Progress Bar */}
                <div className="flex justify-between text-[10px] font-bold text-gray-400 mb-1.5 uppercase">
                   <span>Progress</span>
                   <span className="text-gray-800">{task.progress}%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-1.5 mb-6 overflow-hidden">
                   <div 
                      className="h-full rounded-full bg-gradient-to-r from-red-500 to-red-600 transition-all duration-1000 ease-out" 
                      style={{ width: `${task.progress}%` }}
                   ></div>
                </div>

                {/* Footer Avatar */}
                <div className="flex items-center justify-between pt-4 border-t border-dashed border-gray-100">
                   <div className="flex -space-x-2">
                      <img className="w-7 h-7 rounded-full border-2 border-white object-cover" src={task.assignee} alt="Assignee" />
                      <div className="w-7 h-7 rounded-full border-2 border-white bg-gray-100 flex items-center justify-center text-[10px] text-gray-500 font-bold">+2</div>
                   </div>
                   <button className="w-7 h-7 rounded-full border border-gray-200 flex items-center justify-center text-gray-400 hover:bg-red-50 hover:text-red-500 hover:border-red-200 transition">
                      <i className="fa-regular fa-paper-plane text-xs"></i>
                   </button>
                </div>

              </div>
            ))}

            {/* --- Add New Task Card (Dasdhboard UI Style) --- */}
            <button 
               onClick={() => setIsModalOpen(true)}
               className="border-2 border-dashed border-gray-300 rounded-[20px] flex flex-col justify-center items-center gap-3 text-gray-400 hover:border-red-400 hover:bg-red-50/30 hover:text-red-500 transition-all duration-300 min-h-[260px] group"
            >
               <div className="w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center group-hover:scale-110 transition">
                  <i className="fa-solid fa-plus text-lg"></i>
               </div>
               <span className="font-semibold text-sm">Add New Task</span>
            </button>

          </div>
        </div>
      </main>

      {/* ================= MODAL (Popup) ================= */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm transition-opacity" 
            onClick={() => setIsModalOpen(false)}
          ></div>

          {/* Modal Content */}
          <div className="bg-white rounded-2xl w-full max-w-md p-0 shadow-2xl relative z-10 overflow-hidden transform transition-all scale-100">
             
             {/* Modal Header */}
             <div className="px-8 py-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                <h2 className="text-lg font-bold text-gray-800">Create Task</h2>
                <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-red-500 transition">
                   <i className="fa-solid fa-xmark text-lg"></i>
                </button>
             </div>

             {/* Form */}
             <form onSubmit={handleCreateTask} className="p-8 space-y-5">
                <div>
                   <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Title</label>
                   <input 
                      type="text" 
                      required
                      placeholder="e.g. Redesign Login Page"
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition font-medium"
                      value={newTask.title}
                      onChange={(e) => setNewTask({...newTask, title: e.target.value})}
                   />
                </div>

                <div className="grid grid-cols-2 gap-5">
                   <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Priority</label>
                      <select 
                         className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition font-medium appearance-none"
                         value={newTask.priority}
                         onChange={(e) => setNewTask({...newTask, priority: e.target.value})}
                      >
                         <option value="MEDIUM">MEDIUM</option>
                         <option value="HIGH">HIGH</option>
                         <option value="LOW">LOW</option>
                      </select>
                   </div>
                   <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Due Date</label>
                      <input 
                         type="date" 
                         required
                         className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition font-medium text-gray-500"
                         value={newTask.dueDate}
                         onChange={(e) => setNewTask({...newTask, dueDate: e.target.value})}
                      />
                   </div>
                </div>

                <div className="pt-2">
                   <button 
                      type="submit" 
                      className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl shadow-lg hover:shadow-red-500/30 transition-all active:scale-[0.98]"
                   >
                      Commit Task
                   </button>
                </div>
             </form>
          </div>
        </div>
      )}

    </div>
  );
}

// Sidebar Item Component
function SidebarItem({ icon, text }) {
  return (
    <div className="flex items-center px-4 py-3 text-gray-400 hover:bg-gray-800/50 hover:text-gray-200 rounded-xl cursor-pointer transition-colors duration-200">
      <i className={`fa-solid ${icon} w-6 text-center mr-3`}></i>
      <span className="font-medium text-sm">{text}</span>
    </div>
  );
}