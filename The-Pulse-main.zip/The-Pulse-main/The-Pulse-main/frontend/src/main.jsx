// src/main.jsx
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'

// 1. เปลี่ยนตรงนี้ (เอา App ออก ใส่ TaskDashboard แทน)
// import App from './App.jsx' 
import TaskDashboard from './TaskDashboard.jsx' 

createRoot(document.getElementById('root')).render(
  <StrictMode>
    {/* 2. เปลี่ยนตรงนี้เป็น TaskDashboard */}
    <TaskDashboard />
  </StrictMode>,
)